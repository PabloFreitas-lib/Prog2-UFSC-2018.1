#ifndef OPERACOES_PRIVADO_H
#define OPERACOES_PRIVADO_H

#include "../Header/lista_interface.h"
#include "../Header/le_interface.h"
#include "../Header/operacoes_interface.h"

//estrutura* mallocar_estrutura(void);

struct baba{
    int segundos_2;
    int minutos_2;
    int horas_2;
};

#endif
