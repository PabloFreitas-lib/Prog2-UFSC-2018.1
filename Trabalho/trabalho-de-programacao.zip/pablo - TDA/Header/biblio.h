#ifndef BIBLIO_H
#define BIBLIO_H

#include "../Header/lista_interface.h"
#include "../Header/le_interface.h"
#include "../Header/operacoes_interface.h"
//#include "../Header/lista_privado.h"
//#include "../Header/le_privado.h"
//#include "../Header/operacoes_privado.h"




#endif
