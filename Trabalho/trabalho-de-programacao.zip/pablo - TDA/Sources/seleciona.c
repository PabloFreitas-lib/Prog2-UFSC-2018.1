#include "../Header/lista_privado.h"
#include "../Header/le_privado.h"
#include "../Header/operacoes_privado.h"

lista_t *le_bruto(char *nome_arq){
    lista_t *lista = lista_cria();
    char string[250] = "\0";
    int ctd = 0;
    FILE *arq = fopen(nome_arq, "r");
    while(fgets(string, 250 , arq) != '\0')
        ctd++;
    char **linha_temp = (char**)malloc(sizeof(char*)*(ctd));
    int i=0;
    for(i=0;i<ctd;i++){
        linha_temp[i] = (char*)malloc(sizeof(char*)*250); // 2MB de vazamento
    }
    rewind(arq);
    fgets(linha_temp[0], 250 , arq);
    i=0;
    while(fgets(linha_temp[i], 250 , arq) != '\0'){
        lista_insere_proximo(lista, lista_cauda(lista), linha_temp[i]);
        i++;
    }
    free(linha_temp);
    fclose(arq);
    return(lista);
}

lista_t* listas_listas(lista_t *l, horario *define){
    if(l==NULL){
        return(NULL);
    }
    int i=0;
    lista_t *lista_main = lista_cria();
    int num = numero_jogadores(l);
    lista_t *sub_lista = lista_cria(); // vazamento
    for(i=1;i<=num;i++){
        sub_lista = trata_dados(l,define,i);
        lista_insere_proximo(lista_main,lista_cauda(lista_main),sub_lista);
    }
    sub_lista = NULL;
    //free(sub_lista);
    //lista_destroi(lista_cabeca(sub_lista));
    return(lista_main);
}

horario* definir_horario(void){
  //Parte de entrada do Usuario:

    /*char a[20]="\0";
    char b[20]="\0";
    char c[20]="\0";
    char d[20]="\0";
    scanf("%[^\n]%*c",a);
    setbuf(stdin,NULL);
    scanf("%[^\n]%*c",b);
    setbuf(stdin,NULL);
    scanf("%[^\n]%*c",c);
    setbuf(stdin,NULL);
    scanf("%[^\n]%*c",d);
    setbuf(stdin,NULL);*/
    horario *retorno = (horario*)malloc(sizeof(horario));
    retorno->hora1=21;//atoi(strtok(a,":"));
    retorno->minuto1=28;//atoi(strtok(NULL,":"));
    retorno->segundo1=00;//atoi(strtok(NULL,"\0"));

    retorno->hora2=22;//atoi(strtok(b,":"));
    retorno->minuto2=16;//atoi(strtok(NULL,":"));
    retorno->segundo2=00;//atoi(strtok(NULL,"\0"));

    retorno->hora3=22;//atoi(strtok(c,":"));
    retorno->minuto3=31;//atoi(strtok(NULL,":"));
    retorno->segundo3=00;//atoi(strtok(NULL,"\0"));

    retorno->hora4=23;//atoi(strtok(d,":"));
    retorno->minuto4=20;//atoi(strtok(NULL,":"));
    retorno->segundo4=00;//atoi(strtok(NULL,"\0"));

    //printf("%d:%d:%d a %d:%d:%d\n",retorno->hora1,retorno->minuto1,retorno->segundo1,retorno->hora2,retorno->minuto2,retorno->segundo2);
    //printf("%d:%d:%d a %d:%d:%d\n",retorno->hora3,retorno->minuto3,retorno->segundo3,retorno->hora4,retorno->minuto4,retorno->segundo4);
    return(retorno);
}

void destroi_primario(lista_t **lista){
    celula_t *celula;
    char *string;
    while(lista_cabeca(*lista)!=NULL){
        celula = lista_cabeca(*lista);
        //lista_cabeca(*lista) = lista_proximo(celula);
        (*lista)->cabeca = lista_proximo(celula);
        string = (char*)lista_dado(celula);
        free(string);
        free(celula);
    }
    free(*lista);
    *lista=NULL;
}

void destroi_secundario(lista_t **sub_lista){
    celula_t *cel_aux;
    lista_t *prim;
    celula_t *efet;
    informacao_jogadores *temp;

    while(lista_cabeca(*sub_lista) != NULL){
        cel_aux = lista_cabeca(*sub_lista);
        (*sub_lista)->cabeca = lista_proximo(cel_aux);
        prim = (lista_t*)lista_dado(cel_aux);

        while(lista_cabeca(prim) != NULL){
            efet = lista_cabeca(prim);
            prim->cabeca = lista_proximo(efet);
            temp = (informacao_jogadores*)lista_dado(efet);
            free(temp);
            free(efet);
        }
        free(prim);
        free(cel_aux);
    }
    free(*sub_lista);
    *sub_lista = NULL;
}
