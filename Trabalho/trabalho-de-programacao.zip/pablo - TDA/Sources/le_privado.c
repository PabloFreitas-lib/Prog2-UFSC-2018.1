#include "../Header/lista_privado.h"
#include "../Header/le_privado.h"
#include "../Header/operacoes_privado.h"



int periodo(informacao_jogadores *auxiliar,horario *define){
    if(auxiliar==NULL)
        return(0);

    if((auxiliar->horas==define->hora1) && (auxiliar->horas==define->hora2)){
        if((auxiliar->minutos>=define->minuto1) && (auxiliar->minutos<define->minuto2)){
            return(1);
        }
    }
    else{
        if((auxiliar->horas == define->hora1) && (auxiliar->minutos >= define->minuto1))
            return(1);
        if((auxiliar->horas > define->hora1) && (auxiliar->horas < define->hora2))
            return(1);
        if((auxiliar->horas == define->hora2) && (auxiliar->minutos < define->minuto2))
            return(1);
    }

    if((auxiliar->horas == define->hora3) && (auxiliar->horas == define->hora4)){
        if((auxiliar->minutos >= define->minuto3) && (auxiliar->minutos < define->minuto4)){
            return(2);
        }
    }
    else{
        if((auxiliar->horas == define->hora3) && (auxiliar->minutos >= define->minuto3))
            return(2);
        if((auxiliar->horas > define->hora3) && (auxiliar->horas < define->hora4))
            return(2);
        if((auxiliar->horas == define->hora4) && (auxiliar->minutos < define->minuto4))
            return(2);
    }
    return(0);
}

lista_t* trata_dados(lista_t *l,horario*define,int k){
    if(l==NULL){
        return(NULL);
    }
    lista_t* sub_lista = lista_cria();
    celula_t *cel_aux = l->cabeca;
    int t = 0;
    informacao_jogadores *tratado = (informacao_jogadores*)malloc(sizeof(informacao_jogadores));
        while(cel_aux != NULL){
            tratado = seleciona_dados((char*)lista_dado(cel_aux));
            t = tratado->id;
            if(t == k){
                if(periodo(tratado,define) == 1){
                    tratado->round = 1;
                    lista_insere_proximo(sub_lista,lista_cauda(sub_lista),tratado);
                }
                if(periodo(tratado,define) == 2){
                    tratado->round = 2;
                    lista_insere_proximo(sub_lista,lista_cauda(sub_lista),tratado);
                }
            }
            cel_aux = lista_proximo(cel_aux);
        }
    free(tratado);
    return(sub_lista);
}

int numero_jogadores(lista_t *l){
    if(l==NULL){
        return(0);
    }
    int total;
    celula_t *cel_aux = lista_cauda(l);
    informacao_jogadores *tratado = seleciona_dados((char*)lista_dado(cel_aux));
    total = tratado->id;
    free(tratado);
    return(total);
}

informacao_jogadores *seleciona_dados(char *str_aux){
    if(str_aux == NULL){
        return(NULL);
    }
    char linha_aux[501];
    memset(linha_aux, '\0', sizeof(linha_aux));
    informacao_jogadores *temp = (informacao_jogadores*)malloc(sizeof(informacao_jogadores));
    if(temp == NULL){
        return(NULL);
    }
    strcpy(linha_aux, str_aux);
    strtok(linha_aux, ",");
    temp->id = atoi(strtok(NULL, ","));

    for(int i=4; i>0; i--)
        strtok(NULL, ",");
    temp->horas = atoi(strtok(NULL, ":"));
    temp->minutos = atoi(strtok(NULL, ":"));
    temp->segundos = atoi(strtok(NULL, ","));
    for(int i=6; i>0; i--)
        strtok(NULL, ",");
    temp->vel = atof(strtok(NULL, ","));
    temp->round = 0;
    return(temp);
}

informacao_jogadores* alloca_info(void){
  informacao_jogadores *aux=(informacao_jogadores*)malloc(sizeof(informacao_jogadores));
  return(aux);
}

int mostra_id(informacao_jogadores* aux){
  return(aux->id);
}
