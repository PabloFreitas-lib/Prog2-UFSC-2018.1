#include "../Header/lista_privado.h"
#include "../Header/le_privado.h"
#include "../Header/operacoes_privado.h"

int run_forest_run(celula_t *info_jogador_calc_vel, int vel_compara){
    if(info_jogador_calc_vel == NULL)
        return(0);
    int i=0;
    informacao_jogadores *aux = (informacao_jogadores*)info_jogador_calc_vel->dado;
    if((int)aux->vel >= vel_compara){
        i=1;
    }
    else{
        i=0;
    }
    return(i + run_forest_run(info_jogador_calc_vel->prox, vel_compara));
}

float velo_media(celula_t *aux){
    if(aux==NULL){
        return(0);
    }
    int i=0;
    float media=0;
    informacao_jogadores *temp = (informacao_jogadores*)lista_dado(aux);
    while(aux != NULL){
        temp = (informacao_jogadores*)lista_dado(aux);
        media += temp->vel;
        i++;
        aux = lista_proximo(aux);
    }
    media = media/i;
    return(media);
}


float velo_media_round(celula_t *aux,int temp){
    if(aux==NULL){
        return(0);
    }
    int i=0;
    float media=0;
    informacao_jogadores *info_temp = (informacao_jogadores*)lista_dado(aux);
    while(aux != NULL){
        info_temp = (informacao_jogadores*)lista_dado(aux);
        if(temp == info_temp->round){
            media += info_temp->vel;
            i++;
        }
        aux = lista_proximo(aux);
    }
    media = media/i;
    return(media);
}


float velo_maxima(celula_t *aux){
    if(aux==NULL){
        return(0);
    }
    float velo=0;
    informacao_jogadores *info_temp = (informacao_jogadores*)lista_dado(aux);
    while(aux!=NULL){
        info_temp = (informacao_jogadores*)lista_dado(aux);
        if(info_temp->vel >= velo){
            velo = info_temp->vel;
        }
        aux = lista_proximo(aux);
    }
    return(velo);
}

float distancia(celula_t *aux){
    if(aux==NULL){
        return(0);
    }
    float dist = 0;
    informacao_jogadores *info_temp = (informacao_jogadores*)lista_dado(aux);
    while(aux != NULL){
        info_temp = (informacao_jogadores*)lista_dado(aux);
        dist += (info_temp->vel)/3.6*5;
        aux = lista_proximo(aux);
    }
    return(dist/1000);
}


estrutura * tempo_efetivo(celula_t *aux,int temp){
    if(aux==NULL){
        return(0);
    }
    int k=0;
    int h=0,hf=0;
    int m=0,mf=0;
    int s=0,sf=0;
    informacao_jogadores *info_temp = (informacao_jogadores*)lista_dado(aux);
    estrutura *retorno = (estrutura*)malloc(sizeof(estrutura)); // 2 vazamentos
    while(aux != NULL){
        info_temp = (informacao_jogadores*)lista_dado(aux);
        if(temp == info_temp->round && k==0){
            h = info_temp->horas;
            m = info_temp->minutos;
            s = info_temp->segundos;
            k++;
        }
        if(temp == info_temp->round){
            hf = info_temp->horas;
            mf = info_temp->minutos;
            sf = info_temp->segundos;
        }
        aux=lista_proximo(aux);
    }
    if(sf-s > 0){
        mf+=1;
    }
    sf=0;
    if(mf-m > 0){
        mf=mf-m;
    }
    else{
        hf -= 1;
        mf = mf+60-m;
    }
    hf = hf-h;
    retorno->segundos_2 = sf;
    retorno->minutos_2 = mf;
    retorno->horas_2 = hf;
    //info_temp=NULL;
    //free(info_temp);
    return(retorno);
}


estrutura *tempo_efetivo_total(celula_t *aux){
    if(aux==NULL){
        return(0);
    }
    estrutura* t1 = tempo_efetivo(aux,1);
    estrutura* t2 = tempo_efetivo(aux,2);
    estrutura* tf = (estrutura*)malloc(sizeof(estrutura));
    tf->horas_2 = 0;
    tf->minutos_2 = 0;
    tf->segundos_2 = 0;


    if((t1->segundos_2)+(t2->segundos_2)>=60){
        tf->minutos_2 += 1;
        tf->segundos_2 = (t1->segundos_2)+(t2->segundos_2)-60;
    }
    else{
        tf->segundos_2 = (t1->segundos_2)+(t2->segundos_2);
    }
    if((t1->minutos_2)+(t2->minutos_2)>=60){
        tf->horas_2 += 1;
        tf->minutos_2 += (t2->minutos_2)+(t1->minutos_2)-60;
    }
    else{
        tf->minutos_2 += (t1->minutos_2)+(t2->minutos_2);
    }
    tf->horas_2 += (t1->horas_2)+(t2->horas_2);
    //t1=NULL;
    //t2=NULL;
    free(t1);
    free(t2);
    return(tf);
}
