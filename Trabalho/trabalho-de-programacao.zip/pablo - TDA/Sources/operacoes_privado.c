#include "../Header/lista_privado.h"
#include "../Header/le_privado.h"
#include "../Header/operacoes_privado.h"

/*estrutura* mallocar_estrutura(void){
  estrutura* aux=(estrutura*)malloc(sizeof(estrutura));
  return(aux);

}*/

int mostra_horas(estrutura*aux){
  return(aux->horas_2);
}
int mostra_minutos(estrutura*aux){
  return(aux->minutos_2);
}
int mostra_segundos(estrutura*aux){
  return(aux->segundos_2);
}
