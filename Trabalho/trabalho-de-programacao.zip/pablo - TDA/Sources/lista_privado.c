#include "../Header/lista_privado.h"
#include "../Header/le_privado.h"
#include "../Header/operacoes_privado.h"
int lista_insere_proximo(lista_t *l, celula_t *c,void *elem){
    if(l!=NULL && elem!=NULL){
        celula_t *aux=(celula_t*)malloc(sizeof(celula_t));
        aux->dado = (void*)elem;
        if(lista_vazia(l)){
            l->cabeca=aux;
            l->cauda=aux;
            l->cabeca->ant=NULL;
            l->cabeca->prox=NULL;
            l->tamanho++;
            return(1);
        }else if(c==NULL){
            // inserir na cabeca
        aux->prox=l->cabeca;
        l->cabeca->ant= aux;
        aux->ant=NULL;
        l->cabeca=aux;
        l->tamanho++;
        return(1);
        }else if(c==l->cauda){
            // logo depois da cauda
            aux->prox = NULL; // como vai ser o ultimo entao o prox  null
            l->cauda->prox=aux;
            aux->ant=l->cauda;
            l->cauda=aux;
            l->tamanho++;
            return(1);
        }else{
        // logo depois da cabeca ou meio
            aux->prox = c->prox;//-->
            c->prox->ant = aux; // <--
            aux->ant=c; // <--
            c->prox=aux; // -->
            l->tamanho++;
            return(1);
        }
    return(0);
    }
    return 0;
}

int lista_insere_anterior(lista_t *l, celula_t *c, const void *elem){
if(l!=NULL && elem!=NULL){
        celula_t *aux=(celula_t*)malloc(sizeof(celula_t));
        aux->dado = (void*)elem;
        if(lista_vazia(l)){
            aux->prox = NULL;
            aux->ant = NULL;
            l->cabeca = aux;
            l->cauda = aux;
            l->tamanho++;
            return(1);
        }else if(c==NULL){
            // coloca na cabeca
            aux->prox=l->cabeca;
            l->cabeca->ant;aux;
            aux->ant=NULL;
            l->cabeca=aux;
            l->tamanho++;
            return(1);
        }else if(c==l->cabeca){
            // coloca na cabeca dnv
            aux->prox=l->cabeca;
            l->cabeca->ant;aux;
            aux->ant=NULL;
            l->cabeca=aux;
            l->tamanho++;
            return(1);
        }else{
            // coloca no meio
            c->ant->prox = aux;
            aux->ant=c->ant;
            aux->prox=c;
            c->ant=aux;
            l->tamanho++;
            return(1);
        }
}
    return(0);
}

int lista_remove(lista_t *l, celula_t *c, void **elem){
    if(l!=NULL && c!=NULL && elem!=NULL){
        if(lista_vazia(l))return(0);
        *elem = c->dado;
        celula_t *aux = l->cabeca;
        if(l->tamanho==1){
            aux=l->cabeca;
            l->cabeca=NULL;
            l->cauda=NULL;
            l->tamanho--;
            free(aux);
            return(1);
        }
        if(c==aux){ // removendo da cabeca
            l->cabeca=c->prox;
            l->cabeca->ant = NULL;
            free(aux);
            l->tamanho--;
            return(1);
        }
        aux = l->cauda;
        if(aux==c){// removendo da cauda
            l->cauda = c->ant; // nova cauda
            l->cauda->prox = NULL; // sempre assim
            free(aux);
            l->tamanho--;
            return(1);
        }
        aux= c;
        c->prox->ant = aux->ant;// <--
        c->ant->prox= aux->prox; // -->
        free(aux);
        l->tamanho--;
        return(1);
    }
    return(0);
}
