#include "../Header/lista_privado.h"
#include "../Header/le_privado.h"
#include "../Header/operacoes_privado.h"
lista_t *lista_cria(void){
    lista_t *lista = (lista_t*)malloc(sizeof(lista_t));
    if(lista == NULL)return(NULL);
    lista->tamanho = 0;
    lista->cabeca = NULL;
    lista->cauda = NULL;
    return(lista);
}

void lista_destroi(celula_t *c){
   if(c==NULL)return;
   lista_destroi(c->prox);
   free(c);
   c = NULL;
}

int lista_vazia(lista_t *l){
    if(l!=NULL){
        if(l->tamanho==0){
            return(1);
        }else{
            return(0);
        }
    }
    return(-1);
}
int lista_tamanho(lista_t *l){
    if(l!=NULL){
        return(l->tamanho);
    }else{
        return(-1);
}
}
celula_t *lista_cabeca(lista_t *l){
    if(l!=NULL)return(l->cabeca);
    return(NULL);
}
celula_t *lista_cauda(lista_t *l){
    if(l!=NULL)return(l->cauda);
    return(NULL);
}
void *lista_dado(celula_t *c){
    if(c!=NULL)return(c->dado);
    return(NULL);
}
celula_t *lista_proximo(celula_t *c){
    if(c!=NULL)return(c->prox);
    return(NULL);
}
celula_t *lista_anterior(celula_t *c){
    if(c!=NULL)return(c->ant);
    return(NULL);
}
int lista_eh_cabeca(lista_t *l, celula_t *c){
    if(l!=NULL && c!=NULL){
        if(l->cabeca==c)return(1);
    }
    return(0);
}
int lista_eh_cauda(lista_t *l, celula_t *c){
    if(l!=NULL && c!=NULL){
        if(l->cauda==c)return(1);
    }
    return(0);
}
