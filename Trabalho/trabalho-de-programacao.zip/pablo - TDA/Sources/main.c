#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include "../Header/biblio.h"

int main(void){
    int i=0;
    horario *definir = definir_horario();
    lista_t *lista_bruto = le_bruto("../Doc/exemplo_atividade1.csv"); // Colocar aqui o diretorio do arquivo teste
    lista_t *lolla = listas_listas(lista_bruto, definir);
    celula_t *efetivo = lista_cabeca(lolla);
    //informacao_jogadores *temp = (informacao_jogadores*)malloc(sizeof(informacao_jogadores));
    informacao_jogadores *temp=alloca_info();
    lista_t *aux = lista_cria();

    while(efetivo != NULL){
        aux = lista_dado(efetivo);
        temp = lista_dado(lista_cabeca(aux));
        printf("+--------------------------------------------------------+\n");
        printf("| Dados referentes ao jogador [%.2d]:                      |\n", mostra_id(temp));
        printf("| Quantidade de vezes que alcancou 18 (km/h) ou mais: %.2d |\n", run_forest_run(lista_cabeca(aux), 18));
        printf("| Quantidade de vezes que alcancou 20 (km/h) ou mais: %.2d |\n", run_forest_run(lista_cabeca(aux), 20));
        printf("| Velocidade Media: %.3f (km/h) | %.3f (m/s)           |\n", velo_media(lista_cabeca(aux)), velo_media(lista_cabeca(aux))/3.6);
        printf("| Velocidade Media Round 1: %.3f (km/h) | %.3f (m/s)   |\n", velo_media_round(lista_cabeca(aux),1),velo_media_round(lista_cabeca(aux),1)/3.6);
        printf("| Velocidade Media Round 2: %.3f (km/h) | %.3f (m/s)   |\n", velo_media_round(lista_cabeca(aux),2),velo_media_round(lista_cabeca(aux),2)/3.6);
        printf("| Velocidade Maxima: %.3f (km/h) | %.3f (m/s)         |\n", velo_maxima(lista_cabeca(aux)), velo_maxima(lista_cabeca(aux))/3.6);
        printf("| Distancia Percorrida: %.3f km                         |\n", distancia(lista_cabeca(aux)));
        //estrutura *tito =mallocar_estrutura();
        estrutura *tito = tempo_efetivo(lista_cabeca(aux),1);
        //free(tito);
        printf("| Tempo 1 [H:M:S]: %.2d:%.2d:%.2d                              |\n", mostra_horas(tito),mostra_minutos(tito),mostra_segundos(tito));
        tito = tempo_efetivo(lista_cabeca(aux),2);
        //free(tito);
        printf("| Tempo 2 [H:M:S]: %.2d:%.2d:%.2d                              |\n", mostra_horas(tito),mostra_minutos(tito),mostra_segundos(tito));
        tito = tempo_efetivo_total(lista_cabeca(aux));
        printf("| Tempo Total [H:M:S]: %.2d:%.2d:%.2d                          |\n", mostra_horas(tito),mostra_minutos(tito),mostra_segundos(tito));
        free(tito);
        tito=NULL;
        efetivo = lista_proximo(efetivo);
    }
    printf("+--------------------------------------------------------+\n");

    free(definir);
    destroi_primario(&lista_bruto);
    destroi_secundario(&lolla);
    return(0);
}
