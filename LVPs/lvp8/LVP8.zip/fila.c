#include "fila_privado.h"

//coloque aqui a implementacao das operacoes do TDA fila generico