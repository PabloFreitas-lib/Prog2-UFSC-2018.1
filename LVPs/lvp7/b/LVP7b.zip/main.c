#include "lista_privado.h"
#include "pilha_privado.h"

lista_t *organizar(lista_t *l,celula_t *c,int tam){
    void *aux;
    pilha_desenpilha(l->c,&aux); //pego oq esta no topo da pilha da celula que quero organizar
    
    lista_insere_posicao(l,aux,pilha_cria(tam)); // coloca a celula de volta na lista 
    
}

int main(void){
    int tamanho;
    lista_t *l = lista_cria(NULL,NULL,NULL);
    if(l==NULL)printf("Não possui memoria para criar a lista\n\n");
    scanf("%d",&tamanho);
    for(int i=0;i<tamanho;i++)lista_insere_proximo(l,l>cabeca,pilha_cria(tamanho));
    
    

    
    
    
    
  /*int n,a,b;
  char *name_eins,*name_zwei,*aux_A,*aux_B;
  scanf("%d",&n);
  

  scanf("%s",name_eins);
  if(strcmp(name_eins,"sair")==0){
    printf("Sair\n");
    return(0);
  }
  scanf("%s",aux_A);
  a = atoi(aux_A);
  scanf("%s",name_zwei);
  scanf("%s",aux_B);
  b = atoi(aux_B);


  if(strcmp(name_eins,"mova")==0 && strcmp(name_zwei,"sobre")==0){	 	  	  		  	    	   		  	       	 	
     printf("Move Sobre\n");
  }
  if(strcmp(name_eins,"mova")==0 && strcmp(name_zwei,"topo")==0){
    printf("Move Topo\n");
  }
  if(strcmp(name_eins,"empilhe")==0 && strcmp(name_zwei,"sobre")==0){
    printf("empilha sobre\n");
  }
  if(strcmp(name_eins,"empilhe")==0 && strcmp(name_zwei,"topo")==0){
    printf("Empilha topo\n");
  }
  while(strcmp(name_eins,"sair")!=0){
    strcpy(name_zwei,"");
    strcpy(aux_A,"");
    strcpy(name_zwei,"");
    strcpy(aux_B,"");
    
    scanf("%s",name_eins);
    if(strcmp(name_eins,"sair")==0){
     printf("Exit\n\n");
      return(0);
    }
    scanf("%s",aux_A);
    a = atoi(aux_A);
    
    scanf("%s",name_zwei);
    
    scanf("%s",aux_B);
    b = atoi(aux_B);


        if(strcmp(name_eins,"mova")==0 && strcmp(name_zwei,"sobre")==0){
            printf("Move Sobre\n");
        }
        if(strcmp(name_eins,"mova")==0 && strcmp(name_zwei,"topo")==0){
            printf("Move Topo\n");
        }	 	  	  		  	    	   		  	       	 	
        if(strcmp(name_eins,"empilhe")==0 && strcmp(name_zwei,"sobre")==0){
            printf("empilha sobre\n");
        }
        if(strcmp(name_eins,"empilhe")==0 && strcmp(name_zwei,"topo")==0){
           printf("Empilha topo\n");
        }
    }*/
  return(0);
}
