/*
 * pesquisa_privado.h
 *
 *  Created on: Jun 26, 2018
 *      Author: John
 */

#ifndef PESQUISA_PRIVADO_H_
#define PESQUISA_PRIVADO_H_

#include <stdio.h>
#include <stdlib.h>
#include "pesquisa_interface.h"

//Coloquei aqui a implementacao de funcoes auxiliares que por ventura sejam necessarias a pesquisa binaria


#endif /* PESQUISA_PRIVADO_H_ */
