#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//coloque aqui sua implementacao, incluindo a main e funcoes adicionais
//o nome do arquivo contendo o labirinto sera passado como argumento para o seu programa
//veja exemplo aqui: http://www.dca.fee.unicamp.br/cursos/EA876/apostila/HTML/node145.html

int main(int argc, char *argv[]) {
 
    return 0;   
}