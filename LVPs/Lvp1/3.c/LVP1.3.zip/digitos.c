#include "digitos.h"

//coloque aqui a implementacao das funcoes