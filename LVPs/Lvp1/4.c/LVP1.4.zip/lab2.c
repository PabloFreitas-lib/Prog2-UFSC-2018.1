#include "lab2.h"

/*coloque aqui teu código*/