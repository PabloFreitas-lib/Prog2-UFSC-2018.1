#ifndef fatorial_h
#define fatorial_h

//Assuma que essa funcao esta disponivel para sua utilizacao
unsigned long long fatorial(unsigned int n);

#endif
