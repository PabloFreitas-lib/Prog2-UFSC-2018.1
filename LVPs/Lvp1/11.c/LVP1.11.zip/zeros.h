#ifndef zeros_h
#define zeros_h

#include "fatorial.h"

int numero_zeros(unsigned long long n);

#endif
